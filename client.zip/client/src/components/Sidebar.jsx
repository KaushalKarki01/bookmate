import React from 'react'
import '../styles/sidebar.scss'
import User from '../assets/user.jpg'

const Sidebar = () => {
  return (
    <div className='sidebar'>
        <div className='admin-detail'>
            <div className="profile-img">
                <img src={User} alt="Profile Pic" />
            </div>
            <div className="details">
                <span className='admin-name'>Kaushal Karki</span>
                <span className='admin-address'>Biratnagar, Morang</span>
            </div>
            <hr />
           
        </div>
        <div className='admin-navs'>
            <ul>
                <li>Dashboard</li>
                <li>Users</li>
                <li>Books</li>
                <li>Stats</li>
                <li>Notifications</li>
                <li>Setting</li>
                <li>Profile</li>
                <li>Log out</li>
            </ul>
        </div>
    </div>
  )
}

export default Sidebar
