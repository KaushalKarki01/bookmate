import React from 'react'
import { useNavigate } from 'react-router-dom'
import Kitab from '../assets/book.jpg'

const Book = () => {
    const navigate = useNavigate()

    const bookCard = {
        display: 'flex',
        flexDirection:'column',
        gap:'1.5rem',
        alignItems: 'center',
    }

    const imgStyle = {
        width: '100%',
        objectFit: 'cover',
    }

    const bookTitle = {
        fontSize: '1.7rem',
    }

    // .book-title{
    //     font-size: 2.5rem;
    //     padding: 0 1rem;
    //     //below code for title truncating i.e adding ... at the end if title is long
    //     // white-space: nowrap;
    //     // overflow: hidden;
    //     // text-overflow: ellipsis;
    //     // max-width: 400px;
    // }


  return (
    <>
        <div className="books-card" style={bookCard}>
            <img src={Kitab} alt="book" style={imgStyle} />
            <h4 className='book-title' style={bookTitle}>Harry Potter and The Philosophers Stone</h4>
            <button onClick={()=>navigate('/library/detail')}>View Details</button>
            
        </div>
    </>
  )
}

export default Book
