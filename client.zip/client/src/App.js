import React from "react";
import {Routes, Route} from 'react-router-dom'
import Navbar from "./components/Navbar";
import BookDetail from "./pages/BookDetail";
import Login from "./pages/login/Login";
import Register from "./pages/login/Register";
import Home from "./pages/Home";
import UserInfo from "./pages/UserInfo";
import AddBook from "./pages/AddBook";
import Library from "./pages/Library";
import Dashboard from "./pages/admin/Dashboard";
import ChangePassword from "./pages/login/ChangePassword";
import ForgetPassword from "./pages/login/ForgetPassword";
import OTP from "./pages/login/OTP";
import { Users } from "./pages/admin/Users";
import Books from "./pages/admin/Books";
import Notification from "./pages/admin/Notification";


function App() {
  return (
   <div>
      <Navbar />
      <Routes>
        {/* Temporary Routes */}
        <Route path="/dashboard/users" element={<Users/>}/>
        <Route path="/dashboard/books" element={<Books/>}/>
        <Route path="/dashboard/notification" element={<Notification/>} />


        {/* Need to be imporved routes */}
        <Route path="/" element={<Home />} />
        <Route path="/library" element={<Library/>} />
        <Route path="/library/detail" element={<BookDetail />} />
        <Route path="/dashboard" element={<Dashboard/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/login/forgetpassword" element={<ForgetPassword/>} />
        <Route path="/login/forgetpassword/enterotp" element={<OTP/>} />
        <Route path="/register" element={<Register/>} />
        <Route path="/profile" element={<UserInfo/>} />
        <Route path="/profile/changepassword" element={<ChangePassword/>} />
        <Route path="profile/add" element={<AddBook/>} />
      </Routes>
   </div>
  );
}

export default App;
